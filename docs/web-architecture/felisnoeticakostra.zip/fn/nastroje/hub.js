// Rozcestník ke stažení — stránka jednoho zvířete.
//
// Stejná šablona se vykreslí dvakrát:
//   /kotata/<rok>/<jmeno>/   veřejná    → jen položky s viditelnost: verejne
//   /<uuid>/                 majitelova → navíc všechno s viditelnost: majitel
//
// Rozdíl je JEN v tom, co projde filtrem. Žádná druhá šablona, žádné dva
// seznamy k udržování — a hlavně: veřejná stránka nemá jak vypsat soukromý
// odkaz, protože se k položce vůbec nedostane.

const { E, T, datum } = require('./sablony');

const TEXTY = {
  cs: {
    titulek: 'Dokumentační centrum jedince', kestazeni: 'Soubory ke stažení',
    narozen: 'Narozen', narozena: 'Narozena', matka: 'Matka', otec: 'Otec',
    kocour: 'Kocour', kocka: 'Kočka',
    tisk: 'Vytisknout / Uložit PDF', tiskPopis: 'Vytisknout nebo uložit dokumentaci do PDF',
    tlacitkoTisk: '🖨️ Vytisknout', otevrit: 'Otevřít', stahnout: 'Stáhnout',
    zip: 'Kompletní balíček (ZIP)', zipPopis: 'Všechny dokumenty a testy v jednom archivu',
    certPuvod: 'Osvědčení o původu a jménu', certKmotr: 'Certifikát čestného kmotrovství',
    jenProVas: 'Tato stránka je jen pro vás. Odkaz nikam nesdílejte.',
    verejna: 'Veřejná stránka. Majitel má vlastní adresu s další dokumentací.',
    prazdno: 'Zatím tu není nic ke stažení.', fotky: 'Fotografie a videa',
  },
  en: {
    titulek: 'Documentation Centre', kestazeni: 'Files to download',
    narozen: 'Born', narozena: 'Born', matka: 'Dam', otec: 'Sire',
    kocour: 'Male', kocka: 'Female',
    tisk: 'Print / Save as PDF', tiskPopis: 'Print or save the documentation as PDF',
    tlacitkoTisk: '🖨️ Print', otevrit: 'Open', stahnout: 'Download',
    zip: 'Complete package (ZIP)', zipPopis: 'All documents and tests in one archive',
    certPuvod: 'Certificate of Origin and Name', certKmotr: 'Certificate of Honorary Godparenthood',
    jenProVas: 'This page is yours alone. Please do not share the link.',
    verejna: 'Public page. The owner has a separate address with further documentation.',
    prazdno: 'Nothing to download yet.', fotky: 'Photographs and video',
  },
  fr: {
    titulek: 'Centre de documentation', kestazeni: 'Fichiers à télécharger',
    narozen: 'Né le', narozena: 'Née le', matka: 'Mère', otec: 'Père',
    kocour: 'Mâle', kocka: 'Femelle',
    tisk: 'Imprimer / Enregistrer en PDF', tiskPopis: 'Imprimer ou sauvegarder la documentation en PDF',
    tlacitkoTisk: '🖨️ Imprimer', otevrit: 'Ouvrir', stahnout: 'Télécharger',
    zip: 'Paquet complet (ZIP)', zipPopis: 'Tous les documents et tests dans une archive',
    certPuvod: "Certificat d'origine et de nom", certKmotr: "Certificat de parrainage d'honneur",
    jenProVas: 'Cette page vous est réservée. Merci de ne pas partager le lien.',
    verejna: "Page publique. Le propriétaire dispose d'une adresse séparée.",
    prazdno: 'Rien à télécharger pour le moment.', fotky: 'Photographies et vidéo',
  },
};

const VLAJKY = { cs: '🇨🇿', en: '🇬🇧', fr: '🇫🇷' };
const NAZVY_JAZYKU = { cs: 'Česky', en: 'English', fr: 'Français' };
const IKONY = { dokument: '📄', foto: '🖼️', video: '🎬', certifikat: '📜', zip: '📦', tisk: '🖨️', genetika: '🔬' };

// Jedna karta v seznamu ke stažení.
function karta({ ikona, nadpis, popis, odkaz, tlacitko, zvyraznit, onclick }) {
  const styl = zvyraznit === 'zip' ? ' karta-download zip-karta' : zvyraznit ? ' karta-download karta-akcent' : ' karta-download';
  const vnitrek = `
      <div class="karta-left">
        <div class="karta-ikona">${ikona}</div>
        <div class="karta-text">
          <strong>${E(nadpis)}</strong>
          ${popis ? `<span>${E(popis)}</span>` : ''}
        </div>
      </div>
      <div class="karta-tlacitko">${E(tlacitko)}</div>`;
  return onclick
    ? `<div class="${styl.trim()}" style="cursor:pointer" onclick="${onclick}">${vnitrek}\n    </div>`
    : `<a href="${E(odkaz)}"${odkaz.endsWith('.zip') ? ' download' : ' target="_blank" rel="noopener"'} class="${styl.trim()}">${vnitrek}\n    </a>`;
}

// Sestaví seznam položek ke stažení podle úrovně přístupu.
function polozky({ zvire, assety, jazyk, url, majitel }) {
  const t = TEXTY[jazyk] || TEXTY.cs;
  const ven = [];

  // 1. ZIP — jen pro majitele
  if (majitel) {
    ven.push(karta({
      ikona: IKONY.zip, nadpis: t.zip, popis: t.zipPopis,
      odkaz: `${zvire.jmeno.normalize('NFD').replace(/[̀-ͯ]/g, '')}_Felis_Noetica.zip`,
      tlacitko: t.stahnout, zvyraznit: 'zip',
    }));
  }

  // 2. certifikáty ve všech jazycích, které jsou v datech
  const c = zvire.certifikat;
  if (c && (majitel || (c.viditelnost || 'verejne') === 'verejne')) {
    const nadpisCert = c.typ === 'kmotrovsky' ? t.certKmotr : t.certPuvod;
    for (const j of c.jazyky || [jazyk]) {
      ven.push(karta({
        ikona: IKONY.certifikat,
        nadpis: `${nadpisCert} (${NAZVY_JAZYKU[j] || j})`,
        popis: zvire.kmotr ? `${(zvire.kmotr.osloveni || {})[j] || zvire.kmotr.jmeno}` : null,
        odkaz: `certifikat-${j}.html`, tlacitko: `${VLAJKY[j] || ''} ${t.otevrit}`.trim(),
        zvyraznit: true,
      }));
    }
  }

  // 3. assety — filtr rozhoduje o všem
  const viditelne = assety.filter((a) =>
    a.viditelnost === 'verejne' || (majitel && a.viditelnost === 'majitel'));

  for (const a of viditelne.filter((x) => x.typ === 'dokument')) {
    const p = (a.popisky || {})[jazyk] || (a.popisky || {}).cs || {};
    ven.push(karta({
      ikona: (a.tagy || []).includes('genomia') ? IKONY.genetika : IKONY.dokument,
      nadpis: p.navesti || a.soubor.split('/').pop(),
      popis: p.text, odkaz: url(a.soubor), tlacitko: t.otevrit,
    }));
  }

  // 4. tisk do PDF
  ven.push(karta({ ikona: IKONY.tisk, nadpis: t.tisk, popis: t.tiskPopis, tlacitko: t.tlacitkoTisk, onclick: 'window.print()' }));

  return { karty: ven, fotky: viditelne.filter((x) => x.typ === 'foto' || x.typ === 'video') };
}

function hub({ zvire, jazyk, assety, url, majitel, jazyky = [], koren, jmenem, kontakt }) {
  const j = jazyk || 'cs';
  const t = TEXTY[j] || TEXTY.cs;
  const { karty, fotky } = polozky({ zvire, assety, jazyk: j, url, majitel });

  const prepinac = jazyky.length > 1
    ? `<p class="prepinac">${jazyky.map((x) => x === j
        ? `<strong>${E(NAZVY_JAZYKU[x] || x)}</strong>`
        : `<a href="${E(koren)}${x === jazyky[0] ? '' : x + '/'}">${E(NAZVY_JAZYKU[x] || x)}</a>`).join(' · ')}</p>`
    : '';

  const rodice = [
    zvire.matka ? `${t.matka}: ${jmenem(zvire.matka)}` : null,
    zvire.otec ? `${t.otec}: ${jmenem(zvire.otec)}` : null,
  ].filter(Boolean).join(' · ');

  return `<!DOCTYPE html>
<html lang="${j}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
${majitel ? '<meta name="robots" content="noindex, nofollow, noarchive">' : ''}
<title>${E(zvire.id)} ${E(zvire.jmeno)} — ${E(t.titulek)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,300..800;1,6..72,300..800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/hub.css">
</head>
<body>
<div class="hub-container">
  <div class="hub-header">
    <img src="/assets/images/logo-znacka.png" alt="Felis Noetica" class="hub-logo">
    <p class="jmeno-stanice">Felis Noetica</p>
    <p class="podtitul">INTELLIGENTIA ET CONCORDIA</p>
    <div class="hub-karta">
      <span class="hub-id">${E(zvire.id)}</span>
      <h1 class="hub-jmeno">${E(zvire.formalni_jmeno || zvire.jmeno)}</h1>
      <p class="hub-detail">${E([
        T(zvire.zbarveni, j),
        zvire.pohlavi === 'M' ? `${t.kocour} (♂)` : `${t.kocka} (♀)`,
        `${zvire.pohlavi === 'M' ? t.narozen : t.narozena} ${datum(zvire.narozeni, j)}`,
        rodice,
      ].filter(Boolean).join(' · '))}</p>
    </div>
  </div>

  <h2 class="hub-sekce-nadpis">📥 ${E(t.kestazeni)}</h2>
  <div class="ke-stazeni-mriezka">
    ${karty.join('\n    ')}
  </div>

${fotky.length ? `  <h2 class="hub-sekce-nadpis">${E(t.fotky)}</h2>
  <div class="fotomriezka">
    ${fotky.map((a) => {
      const p = (a.popisky || {})[j] || (a.popisky || {}).cs || {};
      return a.typ === 'video'
        ? `<figure><video controls preload="metadata"><source src="${E(url(a.soubor))}" type="video/mp4"></video>${p.text ? `<figcaption>${E(p.text)}</figcaption>` : ''}</figure>`
        : `<figure><img src="${E(url(a.soubor))}" alt="${E(p.text || zvire.jmeno)}" loading="lazy">${p.text ? `<figcaption>${E(p.text)}</figcaption>` : ''}</figure>`;
    }).join('\n    ')}
  </div>` : ''}

  <footer class="hub-pata">
    ${prepinac}
    <p><a href="mailto:${E(kontakt.email)}">${E(kontakt.email)}</a> · ${E(kontakt.telefon)}</p>
    <p class="poznamka">${E(majitel ? t.jenProVas : t.verejna)}</p>
  </footer>
</div>
</body>
</html>`;
}

module.exports = { hub, TEXTY };
