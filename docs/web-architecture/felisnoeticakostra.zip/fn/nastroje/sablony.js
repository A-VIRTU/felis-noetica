// Šablony. Bez závislostí, obyčejné template literals.
// Třídy odpovídají stávajícímu styl.css, aby generované stránky vypadaly
// jako zbytek webu a nemusel se psát nový styl.

const E = (s) =>
  String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// text v daném jazyce s pádem zpět na češtinu
const T = (preklad, jazyk) => {
  if (!preklad) return '';
  return preklad[jazyk] || preklad.cs || preklad.en || '';
};

const MESICE = ['ledna', 'února', 'března', 'dubna', 'května', 'června', 'července', 'srpna', 'září', 'října', 'listopadu', 'prosince'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// 2026-07-14 -> "14. července 2026" / "14 July 2026"
function datum(d, jazyk = 'cs') {
  if (!d) return '';
  const [r, m, den] = String(d).split('-').map(Number);
  if (!r) return String(d);
  return jazyk === 'en' ? `${den} ${MONTHS[m - 1]} ${r}` : `${den}. ${MESICE[m - 1]} ${r}`;
}

// české počítané podstatné jméno: 1 kotě, 2–4 koťata, 5+ koťat
function kotat(n) {
  if (n === 1) return '1 kotě';
  if (n >= 2 && n <= 4) return `${n} koťata`;
  return `${n} koťat`;
}

const SLOVNIK = {
  cs: {
    dokumenty: 'Dokumenty ke stažení', fotky: 'Fotografie a videa',
    tvoje: 'Vaše zvíře', narozen: 'Narozen', narozena: 'Narozena',
    matka: 'Matka', otec: 'Otec', vrh: 'Vrh', neuvedeno: 'neuvedeno',
    soukrome: 'Tato stránka je jen pro vás. Odkaz nikam nesdílejte.',
    kontakt: 'Kdykoli se ozvěte',
  },
  en: {
    dokumenty: 'Documents', fotky: 'Photographs and video',
    tvoje: 'Your animal', narozen: 'Born', narozena: 'Born',
    matka: 'Dam', otec: 'Sire', vrh: 'Litter', neuvedeno: 'not given',
    soukrome: 'This page is yours alone. Please do not share the link.',
    kontakt: 'Get in touch any time', certifikat: 'Certificate of origin',
  },
  fr: {
    dokumenty: 'Documents', fotky: 'Photographies et vidéo',
    tvoje: 'Votre animal', narozen: 'Né le', narozena: 'Née le',
    matka: 'Mère', otec: 'Père', vrh: 'Portée', neuvedeno: 'non indiqué',
    soukrome: "Cette page vous est réservée. Merci de ne pas partager le lien.",
    kontakt: 'Écrivez-nous quand vous voulez', certifikat: "Certificat d'origine",
  },
};
SLOVNIK.cs.certifikat = 'Osvědčení o původu';

const NAZVY_JAZYKU = { cs: 'Česky', en: 'English', fr: 'Français' };

function rozvrh({ titulek, jazyk = 'cs', telo, noindex = false, korenCss = '/' }) {
  return `<!DOCTYPE html>
<html lang="${jazyk}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
${noindex ? '<meta name="robots" content="noindex, nofollow, noarchive">' : ''}
<title>${E(titulek)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,300;0,400;1,300;1,400&family=Petrona:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
<link rel="stylesheet" href="${korenCss}styl.css">
<link rel="icon" href="${korenCss}favicon.ico">
</head>
<body>
${telo}
<script src="${korenCss}skript.js"></script>
</body>
</html>`;
}

// ---------- figure ----------

function figura(a, jazyk, url) {
  const p = (a.popisky || {})[jazyk] || (a.popisky || {}).cs || {};
  const popis = p.navesti || p.text
    ? `<figcaption>${p.navesti ? `<span class="datum">${E(p.navesti)}</span>` : ''}${p.text ? `<em>${E(p.text)}</em>` : ''}</figcaption>`
    : '';
  const alt = E(p.text || a.soubor);

  if (a.typ === 'video') {
    return `<figure>
  <video controls preload="metadata"${a.poster ? ` poster="${E(url(a.poster))}"` : ''}>
    <source src="${E(url(a.soubor))}" type="video/mp4">
  </video>${popis}
</figure>`;
  }
  if (a.typ === 'dokument') {
    return `<div class="polozka"><span><a href="${E(url(a.soubor))}">${E(p.navesti || a.soubor.split('/').pop())}</a>${p.text ? `<br><span style="font-size:.88rem;color:var(--text-tichy)">${E(p.text)}</span>` : ''}</span><span class="cena">PDF</span></div>`;
  }
  return `<figure>
  <img src="${E(url(a.soubor))}" alt="${alt}" loading="lazy">${popis}
</figure>`;
}

// ---------- privátní stránka majitele ----------

function stranakMajitele({ zvire, jazyk, assety, zvirata, url, kontakt, jazyky = [], uuid, prvni }) {
  const j = jazyk || 'cs';
  const s = SLOVNIK[j] || SLOVNIK.cs;
  // přepínač jazyků: první jazyk sedí na /<uuid>/, další na /<uuid>/<jazyk>/
  const prepinac = jazyky.length > 1
    ? `<p class="odkaz-dal">${jazyky.map((x) => x === j
        ? `<strong>${E(NAZVY_JAZYKU[x] || x)}</strong>`
        : `<a href="/${uuid}/${x === prvni ? '' : x + '/'}">${E(NAZVY_JAZYKU[x] || x)}</a>`).join(' · ')}</p>`
    : '';
  const fotky = assety.filter((a) => a.typ === 'foto' || a.typ === 'video');
  const doks = assety.filter((a) => a.typ === 'dokument');
  const jmenem = (id) => { const z = zvirata.find((x) => x.id === id); return z ? z.jmeno : id; };

  const profily = [zvire].map((z) => `
  <div class="kocka">
    <h3>${E(z.jmeno)}</h3>
    <span class="role">${E(z.pohlavi === 'M' ? s.narozen : s.narozena)} ${E(z.narozeni ? datum(z.narozeni, j) : s.neuvedeno)}${z.matka ? ` · ${E(s.matka)} ${E(jmenem(z.matka))}` : ''}${z.otec ? ` · ${E(s.otec)} ${E(jmenem(z.otec))}` : ''}</span>
    ${T(z.pojmenovan_po, j) ? `<p class="duraz">${E(T(z.pojmenovan_po, j))}</p>` : ''}
    ${T(z.popis, j) ? `<p>${E(T(z.popis, j)).trim().replace(/\n\n+/g, '</p><p>')}</p>` : ''}
  </div>`).join('\n');

  const telo = `
<header class="hlavicka">
  <img class="znak" src="/assets/images/logo.png" alt="Felis Noetica">
  <h1 class="jmeno-stanice">Felis Noetica</h1>
  <p class="podtitul">${E(s.tvoje)}</p>
</header>

<section class="blok obal">
  ${profily}
</section>

${doks.length ? `<section class="prouzek">
  <div class="obal">
    <span class="navesti">${E(s.dokumenty)}</span>
    <div class="cenik">
      ${doks.map((a) => figura(a, j, url)).join('\n      ')}
    </div>
  </div>
</section>` : ''}

${fotky.length ? `<section class="blok obal obal-siroky">
  <span class="navesti">${E(s.fotky)}</span>
  ${fotky.map((a) => figura(a, j, url)).join('\n  ')}
</section>` : ''}

<section class="blok obal">
  <div class="cenik">
    <div class="polozka"><span><a href="/${E(uuid)}/certifikat-${E(j)}.html">${E(s.certifikat)}</a></span><span class="cena">HTML</span></div>
  </div>
</section>

<footer class="pata obal">
  ${prepinac}
  <p class="mail"><a href="mailto:${E(kontakt.email)}">${E(kontakt.email)}</a></p>
  <p>${E(s.kontakt)} — ${E(kontakt.telefon)}</p>
  <p class="uredni">${E(s.soukrome)}</p>
</footer>`;

  return rozvrh({ titulek: `${zvire.jmeno} — Felis Noetica`, jazyk: j, telo, noindex: true });
}

// ---------- fragment aktuálních koťat pro index.html ----------

function fragmentKotata({ vrhy, zvirata, assety, jazyk, url }) {
  const podleVrhu = {};
  for (const z of zvirata) if (z.vrh) (podleVrhu[z.vrh] ||= []).push(z);

  const nahled = (z) => {
    const a = assety.find((x) => x.hlavni === z.id && x.typ === "foto" && x.verejne);
    if (!a) return `<div class="misto"><span>FOTO</span></div>`;
    return `<img src="${E(url(a.soubor))}" alt="${E(z.jmeno)}">`;
  };

  const jm = (id) => { const z = zvirata.find((x) => x.id === id); return z ? z.jmeno : id; };

  return vrhy.filter((v) => v.verejne).map((v) => {
    const kotata = (podleVrhu[v.__slug] || []).filter((z) => z.verejne);
    const pocet = jazyk === 'en' ? `${kotata.length} kittens` : kotat(kotata.length);
    return `<div class="vrh">
  <p class="vrh-hlava">${jazyk === 'en' ? `${E(jm(v.matka))}'s litter` : `Vrh ${E(jm(v.matka))}`}</p>
  <p class="vrh-info">${jazyk === 'en' ? 'born' : 'narozen'} ${E(datum(v.narozeni, jazyk))}, ${E(pocet)}${T(v.poznamka, jazyk) ? ` — ${E(T(v.poznamka, jazyk))}` : ''}</p>
${kotata.map((z) => `  <div class="kote">
    <div class="kote-foto"><figure>${nahled(z)}</figure></div>
    <div class="kote-text">
      <p class="kote-jmeno">${E(z.jmeno)}</p>
      ${T(z.pojmenovan_po, jazyk) ? `<p class="kote-po">${E(T(z.pojmenovan_po, jazyk))}</p>` : ''}
      <span class="stav ${z.stav === 'prodano' ? 'stav-jine' : 'stav-volne'}">${z.stav === 'prodano' ? 'rezervováno' : 'volné'}</span>
    </div>
  </div>`).join('\n')}
</div>`;
  }).join('\n');
}

module.exports = { rozvrh, figura, stranakMajitele, fragmentKotata, E, T, datum, kotat, SLOVNIK };
